// Peaceful Snowfall – offline gyorsítótár
// Oldal és szkriptek: előbb hálózat (friss marad), ha nincs net, a mentett példány.
// Képek és egyéb fájlok: előbb a mentett példány (gyors, offline is megy).
const C='snow-v1';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||r.headers.has('range'))return;
  const u=new URL(r.url);
  if(u.origin!==location.origin)return; // rádió stream és külső logók nincsenek cache-elve
  e.respondWith((async()=>{
    const c=await caches.open(C);
    const hit=await c.match(r,{ignoreSearch:true});
    const code=r.mode==='navigate'||/\.(html|js|webmanifest)$/.test(u.pathname);
    const net=()=>fetch(r).then(res=>{if(res&&res.ok)c.put(r,res.clone());return res}).catch(()=>null);
    if(code){const res=await net();return res||hit||Response.error()}
    return hit||(await net())||Response.error();
  })());
});
